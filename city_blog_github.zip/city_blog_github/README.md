# My City Blog

This is a simple, modern public blog website built to showcase historical and cultural landmarks of a city.  
You can host it freely using **GitHub Pages**.

## Pages included:
- About Us
- Cascade Complex
- Mother Armenia & Victory Park
- Tsitsernakaberd Memorial Complex
- Erebuni Fortress

## Hosting

To publish this site on GitHub Pages:
1. Create a public repository
2. Upload all files from this folder (not the folder itself)
3. Go to Settings > Pages and set the source to the root directory of the main branch
4. Your website will be live at `https://yourusername.github.io/repository-name`
